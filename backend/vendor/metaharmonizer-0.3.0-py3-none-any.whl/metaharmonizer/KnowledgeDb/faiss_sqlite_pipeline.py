import gc
import torch
import sqlite3
import faiss
import os
import asyncio
import httpx
import numpy as np
import pandas as pd
from typing import List
from functools import lru_cache
from metaharmonizer.utils.embeddings import EmbeddingAdapter
from metaharmonizer.utils.model_loader import get_embedding_model_cached
from metaharmonizer.CustomLogger.custom_logger import CustomLogger
from metaharmonizer.KnowledgeDb import ensure_knowledge_db
from metaharmonizer._async_utils import run_async
from metaharmonizer.KnowledgeDb.db_clients.nci_db import NCIDb
from metaharmonizer.KnowledgeDb.concept_table_builder import ConceptTableBuilder
from metaharmonizer.KnowledgeDb.db_clients.ols_db import validate_identifier, validate_table_suffix
from metaharmonizer._paths import VECTOR_DB_PATH, FAISS_INDEX_DIR

# Load API key from environment. Paths resolved via metaharmonizer._paths
# (which honors VECTOR_DB_PATH / FAISS_INDEX_DIR env vars, falling back to
# a per-user cache dir under ~/.metaharmonizer).
BASE_DB = str(VECTOR_DB_PATH)
BASE_IDX_DIR = str(FAISS_INDEX_DIR)
UMLS_API_KEY = os.getenv("UMLS_API_KEY")

TERM_BATCH_SIZE = 60  # Default batch size for term processing


class Document:
    """A simple Document class to hold page content and metadata."""

    def __init__(self, page_content: str, metadata: dict):
        self.page_content = page_content
        self.metadata = metadata


class FAISSSQLiteSearch:
    """
    This class provides a hybrid FAISS + SQLite backend for storing and retrieving
    embedded vectors and associated metadata for ontology mapping.
    It supports both RAG (Retrieval-Augmented Generation) and LM/ST strategies.
    """

    def __init__(
        self,
        method: str,
        category: str,
        om_strategy: str = "rag",
        ontology_source: str = "ncit",
        table_suffix: str = "",
    ):
        ensure_knowledge_db()
        self.is_gpu = faiss.get_num_gpus() > 0
        self._gpu_res = faiss.StandardGpuResources() if self.is_gpu else None
        self.db_path = BASE_DB
        self.db = NCIDb(UMLS_API_KEY)
        self.method = method
        self.om_strategy = om_strategy
        self.category = validate_identifier(category, "category")
        self.ontology_source = validate_identifier(ontology_source, "ontology_source")
        validate_table_suffix(table_suffix)
        self.table_suffix = table_suffix
        if self.om_strategy in ("st", "lm"):
            self.table_name = f"{ontology_source}_corpus_{category}{table_suffix}"
        elif self.om_strategy in ("rag", "rag_bie"):
            self.table_name = f"{ontology_source}_rag_{category}{table_suffix}"
        else:
            raise ValueError(
                f"Unsupported om_strategy: {om_strategy}. Choose from 'rag', 'rag_bie', 'st', 'lm'."
            )
        method_clean = method.replace('-', '_')
        # rag and rag_bie embed the same context table — share one index file
        idx_strategy = "rag" if om_strategy in ("rag", "rag_bie") else om_strategy
        idx_name = f"{idx_strategy}_{method_clean}_{ontology_source}_{category}{table_suffix}.index"
        self.index_path = os.path.join(BASE_IDX_DIR, idx_name)

        raw_model = get_embedding_model_cached(method)
        if self.om_strategy == 'lm':
            lm_model = raw_model[0].auto_model
            self.embedder = EmbeddingAdapter(lm_model, om_strategy='lm')
        else:
            self.embedder = EmbeddingAdapter(raw_model)
        self.logger = CustomLogger().custlogger(loglevel='INFO')
        self.term_batch_size = TERM_BATCH_SIZE

        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()

        if self.om_strategy in ("st", "lm"):
            # Corpus table
            create_sql = f"""
              CREATE TABLE IF NOT EXISTS {self.table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                term TEXT NOT NULL
              )
            """
        elif self.om_strategy in ("rag", "rag_bie"):
            # RAG table (created by ConceptTableBuilder, ensure existence here)
            create_sql = f"""
              CREATE TABLE IF NOT EXISTS {self.table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                term TEXT NOT NULL,
                code TEXT NOT NULL UNIQUE,
                context TEXT NOT NULL
              )
            """

        self.cursor.execute(create_sql)
        self.conn.commit()

        if os.path.exists(self.index_path):
            self.index = faiss.read_index(self.index_path)
            if self.is_gpu:
                self.index = faiss.index_cpu_to_gpu(self._gpu_res, 0, self.index)
            # Load _ids from the persisted file saved at build time so the
            # position→ID mapping always matches the FAISS index, even if
            # the DB table was modified after the index was built.
            ids_path = self.index_path + ".ids.npy"
            if os.path.exists(ids_path):
                self._ids = np.load(ids_path).tolist()
            else:
                # Fallback for indexes built before _ids persistence was added.
                # This is correct only when the DB hasn't changed since building.
                rows = self.cursor.execute(
                    f"SELECT id FROM {self.table_name} ORDER BY id").fetchall()
                self._ids = [r[0] for r in rows]
        else:
            self.index = None
            self._ids = []

    def ensure_corpus_integrity(self,
                                corpus: List[str],
                                corpus_df: pd.DataFrame = None):
        """
        Ensure all terms in the provided corpus are embedded and stored in FAISS and SQLite.
        Strategy-dependent.
        """
        if self.om_strategy in ("rag", "rag_bie"):
            if corpus_df is None:
                raise ValueError("corpus_df is required for RAG strategy")

            if 'clean_code' not in corpus_df.columns:
                if 'obo_id' in corpus_df.columns:
                    corpus_df = corpus_df.copy()
                    def _obo_to_clean_code(x: str) -> str:
                        x = str(x)
                        if ":" not in x:
                            return x
                        prefix, local = x.split(":", 1)
                        return local if prefix == "NCIT" else f"{prefix}_{local}"
                    corpus_df['clean_code'] = corpus_df['obo_id'].astype(str).apply(_obo_to_clean_code)
                else:
                    raise ValueError("corpus_df must contain 'clean_code' or 'obo_id' for RAG strategy")
            codes = corpus_df['clean_code'].dropna().unique().tolist()

            # 1. Use ConceptTableBuilder to build synonym and rag tables.
            #    Skip if tables are already fully populated (e.g. pre-built via build_from_json).
            with sqlite3.connect(BASE_DB) as _conn:
                try:
                    stored_codes = {
                        r[0] for r in _conn.execute(
                            f"SELECT DISTINCT code FROM {self.table_name}"
                        ).fetchall()
                    }
                except sqlite3.OperationalError:
                    stored_codes = set()
            missing_codes = [c for c in codes if c not in stored_codes]

            if missing_codes:
                builder = ConceptTableBuilder(self.category, ontology_source=self.ontology_source,
                                              table_suffix=self.table_suffix)
                run_async(builder.fetch_and_build_tables(missing_codes, force_rebuild=False))
            else:
                self.logger.info(
                    f"RAG tables for '{self.category}' are pre-built; skipping NCI fetch"
                )

            # 2. Check and build FAISS index
            self._ensure_faiss_index()

        else:
            # ST/LM Strategy
            existing_terms = self._get_existing_terms()
            missing_terms = [
                term for term in corpus if term not in existing_terms
            ]

            if missing_terms:
                self.logger.info(
                    f"Adding {len(missing_terms)} new terms to corpus table")
                self._populate_corpus_table(missing_terms)
            else:
                self.logger.info("All corpus terms already in table")

            self._ensure_faiss_index()

        self._get_existing_terms.cache_clear()

    def _populate_corpus_table(self, corpus: List[str]):
        """
        Fill corpus table (for ST/LM)
        
        Only store terms, do not call NCI API
        """
        records = [(t, ) for t in corpus]
        self.cursor.executemany(
            f"INSERT INTO {self.table_name}(term) VALUES(?)", records)
        self.conn.commit()
        self.logger.info(
            f"✅ Inserted {len(records)} terms into {self.table_name}")

    def _ensure_faiss_index(self):
        """
        Ensure FAISS index exists and is synchronized with the table
        """
        # Check the number of records in the table
        table_count = self.cursor.execute(
            f"SELECT COUNT(*) FROM {self.table_name}").fetchone()[0]

        if table_count == 0:
            self.logger.warning(f"Table {self.table_name} is empty")
            return

        # Check index status
        need_rebuild = False

        if not os.path.exists(self.index_path):
            self.logger.info(f"FAISS index not found, will build")
            need_rebuild = True
        elif self.index is None:
            self.logger.info(f"FAISS index not loaded, will build")
            need_rebuild = True
        elif self.index.ntotal != table_count:
            self.logger.info(
                f"⚠️ Index mismatch (table: {table_count}, index: {self.index.ntotal}), rebuilding..."
            )
            need_rebuild = True
        else:
            self.logger.info(
                f"✅ FAISS index up-to-date ({self.index.ntotal} vectors)")
            return

        # Rebuild index
        if need_rebuild:
            self._build_faiss_from_table()

    def _build_faiss_from_table(self):
        """
        Read data from table and build FAISS index
        
        General method: supports all strategies
        """
        # Read different columns based on strategy
        if self.om_strategy in ("rag", "rag_bie"):
            # RAG: Read context
            rows = self.cursor.execute(
                f"SELECT id, context FROM {self.table_name} ORDER BY id"
            ).fetchall()
            texts = [row[1] for row in rows]
        else:
            # ST/LM: Read term
            rows = self.cursor.execute(
                f"SELECT id, term FROM {self.table_name} ORDER BY id"
            ).fetchall()
            texts = [row[1] for row in rows]

        if not rows:
            self.logger.warning(f"No data in table {self.table_name}")
            return

        db_ids = [row[0] for row in rows]

        self.logger.info(f"Embedding {len(texts)} texts with {self.method}")

        # Batch embedding
        embed_batch_size = 512
        if self.is_gpu:
            total_mem = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            used_mem = torch.cuda.memory_allocated(0) / (1024**3)
            free_mem = total_mem - used_mem

            if free_mem < 2:
                embed_batch_size = max(64, embed_batch_size // 2)
            elif free_mem > 8:
                embed_batch_size = min(2048, embed_batch_size * 2)

        self.index = None  # reset
        self._ids = []

        n_batches = (len(texts) + embed_batch_size - 1) // embed_batch_size
        for batch_idx, i in enumerate(range(0, len(texts), embed_batch_size)):
            batch_texts = texts[i:i + embed_batch_size]
            batch_ids   = db_ids[i:i + embed_batch_size]

            batch_array = np.array(self.embedder.embed_documents(batch_texts), dtype=np.float32)
            batch_array = self.normalize(batch_array)

            if self.index is None:
                dim = batch_array.shape[1]
                cpu_index = faiss.IndexFlatIP(dim)
                self.index = faiss.index_cpu_to_gpu(self._gpu_res, 0, cpu_index) if self.is_gpu else cpu_index

            self.index.add(batch_array)
            self._ids.extend(batch_ids)

            del batch_texts, batch_array
            if self.is_gpu:
                torch.cuda.empty_cache()
            gc.collect()

            if (batch_idx + 1) % 10 == 0 or (batch_idx + 1) == n_batches:
                self.logger.info(f"Embedding progress: {batch_idx + 1}/{n_batches} batches")

        # Save (GPU indices must be converted to CPU before writing)
        os.makedirs(BASE_IDX_DIR, exist_ok=True)
        index_to_save = faiss.index_gpu_to_cpu(self.index) if self.is_gpu else self.index
        faiss.write_index(index_to_save, self.index_path)
        # Persist _ids alongside the index so the position→DB-ID mapping is
        # always in sync, even if the DB table changes later.
        np.save(self.index_path + ".ids.npy", np.array(self._ids, dtype=np.int64))
        self.logger.info(f"Index saved ({'GPU' if self.is_gpu else 'CPU'} mode)")

        self.logger.info(f"✅ FAISS index built: {self.index.ntotal} vectors")

    @lru_cache(maxsize=1)
    def _get_existing_terms(self):
        """Return a set of terms already in the database.
        Used to avoid duplicate API calls.
        """
        self.cursor.execute(f"SELECT term FROM {self.table_name}")
        return set(row[0] for row in self.cursor.fetchall())

    def normalize(self, v: np.ndarray) -> np.ndarray:
        """Normalize rows of v to unit length for cosine-similarity via IndexFlatIP."""
        if getattr(self, "embedder", None) and getattr(
                self.embedder.model, "_is_normalized", False):
            return v
        v = v.astype('float32', copy=False)
        norms = np.linalg.norm(v, axis=1, keepdims=True)
        return v / (norms + 1e-12)

    def similarity_search(self,
                          query: str,
                          k: int = 5,
                          as_documents: bool = False):
        """Perform similarity search over FAISS index and return top-k matches.
        Only works with RAG strategy.
        Args:
            query (str): The query string to search for.
            k (int): Number of top matches to return.
            as_documents (bool): If True, return results as Document objects.
        Returns:
            List[dict] or List[Document]: A list of dictionaries or Document objects containing the
            term, context, code, and score for each match.
        Raises:
            NotImplementedError: If the strategy is not RAG.
        """
        if self.om_strategy not in ("rag", "rag_bie"):
            raise NotImplementedError(
                "LM/ST strategy should use get_match_results method.")

        vector = self.embedder.embed_query(query)
        vector = np.array(vector, dtype="float32").reshape(1, -1)
        vector = self.normalize(vector)
        distances, indices = self.index.search(vector, k)
        results = []
        for db_idx, score in zip(indices[0], distances[0]):
            if db_idx == -1:
                continue
            record_id = self._ids[db_idx]
            row = self.cursor.execute(
                f"SELECT term, context, code FROM {self.table_name} WHERE id = ?",
                (record_id, )).fetchone()
            if row:
                term, context, code = row
                result = {
                    "term": term,
                    "context": context,
                    "code": code,
                    "score": float(score)
                }
                if as_documents:
                    results.append(
                        Document(page_content=context, metadata=result))
                else:
                    results.append(result)
        return results

    def close(self):
        self.conn.close()
